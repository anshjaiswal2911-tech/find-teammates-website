import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Code2,
  Trophy,
  Users,
  BookOpen,
  Target,
  Brain,
  Sparkles,
  TrendingUp,
  MessageCircle,
  Video,
  Award,
  Rocket,
  Zap,
  Star,
  CheckCircle,
  Clock,
  Activity,
  GitBranch,
  FileCode,
  Lightbulb,
  Play,
  Heart,
  Eye,
  Calendar,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { DashboardLayout } from '../components/DashboardLayout';
import { Progress } from '../components/ui/progress';
import { addActivity } from '../lib/userStats';
import { useAuth } from '../contexts/AuthContext';

export function SuperFeatures() {
  const { user } = useAuth();
  const [activeFeature, setActiveFeature] = useState<string | null>(null);
  const [selectedRoadmap, setSelectedRoadmap] = useState<string | null>(null);
  const [bookingMentor, setBookingMentor] = useState<string | null>(null);

  return (
    <DashboardLayout>
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <Rocket className="h-8 w-8 text-purple-600" />
          <h1 className="text-3xl font-bold text-gray-900">Super Features Hub</h1>
        </div>
        <p className="text-gray-600">
          Explore all premium features in one place
        </p>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="learning">Learning</TabsTrigger>
          <TabsTrigger value="collaboration">Collaboration</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="mentorship">Mentorship</TabsTrigger>
        </TabsList>

        {/* OVERVIEW TAB */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Feature 4: Skill Assessment Quiz */}
            <FeatureCard
              icon={Brain}
              title="Skill Assessment Quiz"
              description="Interactive quizzes to validate your skills"
              color="bg-blue-600"
              stats={[
                { label: 'Quizzes Available', value: '50+' },
                { label: 'Topics', value: '15' },
              ]}
              onClick={() => setActiveFeature('quiz')}
            />

            {/* Feature 5: Project Showcase */}
            <FeatureCard
              icon={Star}
              title="Project Showcase"
              description="Display your best projects with likes & comments"
              color="bg-purple-600"
              stats={[
                { label: 'Total Projects', value: '1.2K' },
                { label: 'Featured', value: '24' },
              ]}
              onClick={() => setActiveFeature('showcase')}
            />

            {/* Feature 6: Mentor Matching */}
            <FeatureCard
              icon={Target}
              title="Mentor Matching"
              description="Connect with industry experts"
              color="bg-green-600"
              stats={[
                { label: 'Mentors', value: '250+' },
                { label: 'Sessions', value: '1.5K' },
              ]}
              onClick={() => setActiveFeature('mentor')}
            />

            {/* Feature 7: Advanced Analytics */}
            <FeatureCard
              icon={Activity}
              title="Advanced Analytics"
              description="Track your learning with heatmaps & charts"
              color="bg-orange-600"
              stats={[
                { label: 'Activity Score', value: '95%' },
                { label: 'Streak', value: '12 days' },
              ]}
              onClick={() => setActiveFeature('analytics')}
            />

            {/* Feature 8: Live Study Rooms */}
            <FeatureCard
              icon={Video}
              title="Live Study Rooms"
              description="Join topic-based study sessions"
              color="bg-pink-600"
              stats={[
                { label: 'Active Rooms', value: '45' },
                { label: 'Participants', value: '2.3K' },
              ]}
              onClick={() => setActiveFeature('studyrooms')}
            />

            {/* Feature 9: Code Snippet Library */}
            <FeatureCard
              icon={FileCode}
              title="Code Snippet Library"
              description="Share and discover useful code snippets"
              color="bg-indigo-600"
              stats={[
                { label: 'Snippets', value: '5.2K' },
                { label: 'Languages', value: '20+' },
              ]}
              onClick={() => setActiveFeature('snippets')}
            />

            {/* Feature 10: Smart Team Formation */}
            <FeatureCard
              icon={Users}
              title="Smart Team Formation"
              description="AI-powered team building algorithm"
              color="bg-cyan-600"
              stats={[
                { label: 'Teams Formed', value: '850+' },
                { label: 'Success Rate', value: '94%' },
              ]}
              onClick={() => setActiveFeature('teamformation')}
            />

            {/* Feature 11: Learning Roadmaps */}
            <FeatureCard
              icon={TrendingUp}
              title="Learning Roadmaps"
              description="Visual paths for different tech stacks"
              color="bg-red-600"
              stats={[
                { label: 'Roadmaps', value: '25+' },
                { label: 'Followers', value: '12K' },
              ]}
              onClick={() => setActiveFeature('roadmaps')}
            />

            {/* Feature 12: Peer Code Review */}
            <FeatureCard
              icon={GitBranch}
              title="Peer Code Review"
              description="Get feedback from experienced developers"
              color="bg-yellow-600"
              stats={[
                { label: 'Reviews', value: '3.5K' },
                { label: 'Avg Rating', value: '4.8/5' },
              ]}
              onClick={() => setActiveFeature('codereview')}
            />
          </div>
        </TabsContent>

        {/* LEARNING TAB */}
        <TabsContent value="learning" className="space-y-6">
          <LearningRoadmaps />
          <SkillAssessment />
        </TabsContent>

        {/* COLLABORATION TAB */}
        <TabsContent value="collaboration" className="space-y-6">
          <CodeSnippets />
          <PeerReview />
        </TabsContent>

        {/* ANALYTICS TAB */}
        <TabsContent value="analytics" className="space-y-6">
          <AdvancedAnalytics />
        </TabsContent>

        {/* MENTORSHIP TAB */}
        <TabsContent value="mentorship" className="space-y-6">
          <MentorMatching />
          <LiveStudyRooms />
        </TabsContent>
      </Tabs>

      {/* Feature Detail Modal */}
      <AnimatePresence>
        {activeFeature && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
            onClick={() => setActiveFeature(null)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-lg max-w-2xl w-full p-6"
            >
              <FeatureDetailContent feature={activeFeature} />
              <Button className="w-full mt-4" onClick={() => setActiveFeature(null)}>
                Close
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </DashboardLayout>
  );
}

// Feature Card Component
function FeatureCard({
  icon: Icon,
  title,
  description,
  color,
  stats,
  onClick,
}: {
  icon: any;
  title: string;
  description: string;
  color: string;
  stats: { label: string; value: string }[];
  onClick: () => void;
}) {
  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -5 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="cursor-pointer"
    >
      <Card className="border-2 hover:shadow-lg transition-all">
        <CardContent className="p-6">
          <div className={`${color} h-12 w-12 rounded-lg flex items-center justify-center mb-4`}>
            <Icon className="h-6 w-6 text-white" />
          </div>
          <h3 className="text-lg font-bold text-gray-900 mb-2">{title}</h3>
          <p className="text-sm text-gray-600 mb-4">{description}</p>
          <div className="grid grid-cols-2 gap-3">
            {stats.map((stat, idx) => (
              <div key={idx} className="bg-gray-50 p-2 rounded">
                <div className="text-xs text-gray-600">{stat.label}</div>
                <div className="text-sm font-bold text-gray-900">{stat.value}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Learning Roadmaps Component
function LearningRoadmaps() {
  const roadmaps = [
    {
      id: '1',
      title: 'Full Stack Developer',
      description: 'Complete path from frontend to backend',
      progress: 65,
      steps: 12,
      completed: 8,
      duration: '6 months',
      difficulty: 'Intermediate',
    },
    {
      id: '2',
      title: 'AI/ML Engineer',
      description: 'Master machine learning and AI',
      progress: 30,
      steps: 15,
      completed: 5,
      duration: '8 months',
      difficulty: 'Advanced',
    },
    {
      id: '3',
      title: 'Mobile App Developer',
      description: 'Build iOS and Android apps',
      progress: 45,
      steps: 10,
      completed: 4,
      duration: '5 months',
      difficulty: 'Beginner',
    },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-blue-600" />
          Learning Roadmaps
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {roadmaps.map((roadmap) => (
          <div key={roadmap.id} className="border rounded-lg p-4">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h4 className="font-semibold text-gray-900">{roadmap.title}</h4>
                <p className="text-sm text-gray-600">{roadmap.description}</p>
              </div>
              <Badge>{roadmap.difficulty}</Badge>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">
                  {roadmap.completed}/{roadmap.steps} steps completed
                </span>
                <span className="text-gray-600">{roadmap.duration}</span>
              </div>
              <Progress value={roadmap.progress} className="h-2" />
              <div className="text-right text-sm font-semibold text-blue-600">
                {roadmap.progress}%
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

// Skill Assessment Component
function SkillAssessment() {
  const { user } = useAuth();
  const [quizzes, setQuizzes] = useState([
    { id: '1', title: 'JavaScript Fundamentals', questions: 20, duration: '30 min', score: 85, taken: true },
    { id: '2', title: 'React Advanced', questions: 25, duration: '40 min', score: null, taken: false },
    { id: '3', title: 'System Design', questions: 30, duration: '45 min', score: 92, taken: true },
    { id: '4', title: 'Data Structures', questions: 35, duration: '50 min', score: null, taken: false },
  ]);

  const startQuiz = (quizId: string, quizTitle: string) => {
    const randomScore = Math.floor(Math.random() * 30) + 70; // 70-100
    setQuizzes(quizzes.map(q => 
      q.id === quizId ? { ...q, taken: true, score: randomScore } : q
    ));
    
    addActivity(
      user?.email || 'default',
      'quiz',
      `Completed ${quizTitle}`,
      randomScore >= 90 ? 50 : randomScore >= 80 ? 30 : 20
    );
    
    alert(`🎉 Quiz completed! Your score: ${randomScore}%`);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5 text-purple-600" />
          Skill Assessment Quizzes
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-2 gap-4">
          {quizzes.map((quiz) => (
            <div
              key={quiz.id}
              className={`border-2 rounded-lg p-4 ${
                quiz.taken ? 'bg-green-50 border-green-300' : 'bg-gray-50 border-gray-300'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <h4 className="font-semibold text-gray-900">{quiz.title}</h4>
                {quiz.taken && (
                  <Badge className="bg-green-600">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Completed
                  </Badge>
                )}
              </div>
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <FileCode className="h-4 w-4" />
                  {quiz.questions} questions
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  {quiz.duration}
                </div>
                {quiz.score !== null && (
                  <div className="text-lg font-bold text-green-600">Score: {quiz.score}%</div>
                )}
              </div>
              <Button 
                className="w-full mt-3" 
                variant={quiz.taken ? 'outline' : 'default'}
                onClick={() => startQuiz(quiz.id, quiz.title)}
              >
                {quiz.taken ? 'Retake Quiz' : 'Start Quiz'}
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// Code Snippets Component
function CodeSnippets() {
  const snippets = [
    {
      id: '1',
      title: 'React Custom Hook',
      language: 'TypeScript',
      author: 'Rahul Sharma',
      likes: 234,
      views: 1200,
      tags: ['React', 'Hooks', 'TypeScript'],
    },
    {
      id: '2',
      title: 'Python Data Processing',
      language: 'Python',
      author: 'Priya Singh',
      likes: 189,
      views: 890,
      tags: ['Python', 'Data Science', 'Pandas'],
    },
    {
      id: '3',
      title: 'API Authentication Middleware',
      language: 'JavaScript',
      author: 'Arjun Patel',
      likes: 312,
      views: 1500,
      tags: ['Node.js', 'Express', 'Auth'],
    },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileCode className="h-5 w-5 text-indigo-600" />
          Popular Code Snippets
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {snippets.map((snippet) => (
          <div key={snippet.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h4 className="font-semibold text-gray-900">{snippet.title}</h4>
                <p className="text-sm text-gray-600">by {snippet.author}</p>
              </div>
              <Badge>{snippet.language}</Badge>
            </div>
            <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
              <span className="flex items-center gap-1">
                <Star className="h-4 w-4 text-yellow-500" />
                {snippet.likes}
              </span>
              <span className="flex items-center gap-1">
                <Activity className="h-4 w-4" />
                {snippet.views} views
              </span>
            </div>
            <div className="flex gap-2 flex-wrap mb-3">
              {snippet.tags.map((tag) => (
                <Badge key={tag} variant="outline" className="text-xs">
                  {tag}
                </Badge>
              ))}
            </div>
            <Button variant="outline" className="w-full">
              View Code
            </Button>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

// Peer Review Component
function PeerReview() {
  const reviews = [
    {
      id: '1',
      project: 'E-commerce Website',
      reviewer: 'Senior Dev @Google',
      rating: 4.5,
      feedback: 'Great implementation! Consider adding error boundaries.',
      date: '2 days ago',
    },
    {
      id: '2',
      project: 'Weather App',
      reviewer: 'Tech Lead @Microsoft',
      rating: 4.8,
      feedback: 'Excellent UI/UX design. API handling is solid.',
      date: '5 days ago',
    },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <GitBranch className="h-5 w-5 text-green-600" />
          Recent Code Reviews
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {reviews.map((review) => (
          <div key={review.id} className="border rounded-lg p-4">
            <div className="flex items-start justify-between mb-2">
              <h4 className="font-semibold text-gray-900">{review.project}</h4>
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-4 w-4 ${
                      i < review.rating ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
            </div>
            <p className="text-sm text-gray-600 mb-2">Reviewed by {review.reviewer}</p>
            <p className="text-sm text-gray-700 mb-2">{review.feedback}</p>
            <p className="text-xs text-gray-500">{review.date}</p>
          </div>
        ))}
        <Button className="w-full">Request New Review</Button>
      </CardContent>
    </Card>
  );
}

// Advanced Analytics Component
function AdvancedAnalytics() {
  return (
    <div className="grid md:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Activity Heatmap</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2">
            {[...Array(35)].map((_, i) => (
              <div
                key={i}
                className={`h-8 rounded ${
                  Math.random() > 0.7
                    ? 'bg-green-600'
                    : Math.random() > 0.4
                    ? 'bg-green-400'
                    : Math.random() > 0.2
                    ? 'bg-green-200'
                    : 'bg-gray-100'
                }`}
                title={`Activity: ${Math.floor(Math.random() * 10)} contributions`}
              />
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Learning Metrics</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[
            { label: 'Code Sessions', value: 45, max: 50, color: 'bg-blue-600' },
            { label: 'Resources Completed', value: 32, max: 40, color: 'bg-green-600' },
            { label: 'Team Collaborations', value: 18, max: 25, color: 'bg-purple-600' },
            { label: 'Quizzes Passed', value: 12, max: 15, color: 'bg-orange-600' },
          ].map((metric, idx) => (
            <div key={idx}>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">{metric.label}</span>
                <span className="text-sm text-gray-600">
                  {metric.value}/{metric.max}
                </span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className={`h-full ${metric.color}`}
                  style={{ width: `${(metric.value / metric.max) * 100}%` }}
                />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

// Mentor Matching Component
function MentorMatching() {
  const { user } = useAuth();
  const mentors = [
    {
      id: '1',
      name: 'Dr. Rajesh Kumar',
      role: 'Senior Engineer @Google',
      expertise: ['System Design', 'AI/ML', 'Cloud'],
      rating: 4.9,
      sessions: 150,
      avatar: 'RK',
    },
    {
      id: '2',
      name: 'Priya Sharma',
      role: 'Tech Lead @Microsoft',
      expertise: ['React', 'TypeScript', 'Architecture'],
      rating: 4.8,
      sessions: 120,
      avatar: 'PS',
    },
    {
      id: '3',
      name: 'Amit Verma',
      role: 'Principal Engineer @Amazon',
      expertise: ['Backend', 'Microservices', 'AWS'],
      rating: 4.7,
      sessions: 98,
      avatar: 'AV',
    },
  ];

  const bookMentorSession = (mentorName: string) => {
    addActivity(
      user?.email || 'default',
      'mentorship',
      `Booked session with ${mentorName}`,
      40
    );
    alert(`✅ Session booked with ${mentorName}!\n\n📅 Your session is scheduled for tomorrow at 10:00 AM\n📧 Check your email for the meeting link`);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Target className="h-5 w-5 text-green-600" />
          Featured Mentors
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-3 gap-4">
          {mentors.map((mentor) => (
            <div key={mentor.id} className="border-2 rounded-lg p-4 hover:shadow-lg transition-shadow">
              <div className="flex flex-col items-center text-center mb-4">
                <div className="h-16 w-16 rounded-full bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center text-white text-xl font-bold mb-2">
                  {mentor.avatar}
                </div>
                <h4 className="font-semibold text-gray-900">{mentor.name}</h4>
                <p className="text-sm text-gray-600">{mentor.role}</p>
              </div>
              <div className="flex items-center justify-center gap-4 mb-3 text-sm">
                <span className="flex items-center gap-1">
                  <Star className="h-4 w-4 text-yellow-500" />
                  {mentor.rating}
                </span>
                <span className="text-gray-600">{mentor.sessions} sessions</span>
              </div>
              <div className="flex flex-wrap gap-1 justify-center mb-3">
                {mentor.expertise.map((skill) => (
                  <Badge key={skill} variant="outline" className="text-xs">
                    {skill}
                  </Badge>
                ))}
              </div>
              <Button 
                className="w-full"
                onClick={() => bookMentorSession(mentor.name)}
              >
                <Calendar className="h-4 w-4 mr-2" />
                Book Session
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// Live Study Rooms Component
function LiveStudyRooms() {
  const { user } = useAuth();
  const [rooms, setRooms] = useState([
    { id: '1', topic: 'React Interview Prep', participants: 12, host: 'Rahul', live: true },
    { id: '2', topic: 'DSA Problem Solving', participants: 8, host: 'Priya', live: true },
    { id: '3', topic: 'System Design Discussion', participants: 15, host: 'Arjun', live: true },
    { id: '4', topic: 'ML Algorithms Study', participants: 6, host: 'Neha', live: false },
  ]);

  const joinRoom = (roomId: string, topic: string, isLive: boolean) => {
    if (isLive) {
      setRooms(rooms.map(r => 
        r.id === roomId ? { ...r, participants: r.participants + 1 } : r
      ));
      
      addActivity(
        user?.email || 'default',
        'collaboration',
        `Joined study room: ${topic}`,
        25
      );
      
      alert(`🎉 Joined "${topic}"!\n\n👥 ${rooms.find(r => r.id === roomId)?.participants! + 1} participants\n🎥 Starting video call...`);
    } else {
      alert(`📅 This room is scheduled for later.\n\n✉️ We'll notify you when it starts!`);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Video className="h-5 w-5 text-pink-600" />
          Live Study Rooms
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-2 gap-4">
          {rooms.map((room) => (
            <div
              key={room.id}
              className={`border-2 rounded-lg p-4 ${
                room.live ? 'bg-red-50 border-red-300' : 'bg-gray-50 border-gray-300'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <h4 className="font-semibold text-gray-900">{room.topic}</h4>
                {room.live && (
                  <Badge className="bg-red-600">
                    <span className="animate-pulse mr-1">●</span> LIVE
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                <span className="flex items-center gap-1">
                  <Users className="h-4 w-4" />
                  {room.participants}
                </span>
                <span>Host: {room.host}</span>
              </div>
              <Button 
                className="w-full" 
                variant={room.live ? 'default' : 'outline'}
                onClick={() => joinRoom(room.id, room.topic, room.live)}
              >
                <Play className="h-4 w-4 mr-2" />
                {room.live ? 'Join Now' : 'Notify Me'}
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// Feature Detail Content
function FeatureDetailContent({ feature }: { feature: string }) {
  const content = {
    quiz: {
      title: 'Skill Assessment Quiz',
      description: 'Take interactive quizzes to validate and showcase your technical skills.',
      features: [
        'Multiple difficulty levels',
        'Real-time scoring',
        'Detailed explanations',
        'Certificate of completion',
      ],
    },
    showcase: {
      title: 'Project Showcase',
      description: 'Display your best projects and get feedback from the community.',
      features: [
        'Upload project screenshots',
        'Add live demo links',
        'Receive likes and comments',
        'Featured project section',
      ],
    },
    mentor: {
      title: 'Mentor Matching',
      description: 'Connect with experienced professionals for guidance and career advice.',
      features: [
        'AI-powered mentor matching',
        '1-on-1 video sessions',
        'Schedule management',
        'Session recordings',
      ],
    },
    analytics: {
      title: 'Advanced Analytics',
      description: 'Track your learning progress with detailed metrics and visualizations.',
      features: [
        'Activity heatmap',
        'Skill progress tracking',
        'Time spent analytics',
        'Personalized insights',
      ],
    },
    studyrooms: {
      title: 'Live Study Rooms',
      description: 'Join or create live study sessions with other learners.',
      features: [
        'Topic-based rooms',
        'Screen sharing',
        'Collaborative whiteboard',
        'Recording available',
      ],
    },
    snippets: {
      title: 'Code Snippet Library',
      description: 'Save, share, and discover useful code snippets.',
      features: [
        'Syntax highlighting',
        'Copy with one click',
        'Tag-based search',
        'Version history',
      ],
    },
    teamformation: {
      title: 'Smart Team Formation',
      description: 'AI algorithm that creates balanced teams based on skills.',
      features: [
        'Skill complementarity analysis',
        'Personality matching',
        'Project type optimization',
        'Success prediction',
      ],
    },
    roadmaps: {
      title: 'Learning Roadmaps',
      description: 'Follow structured learning paths for different career tracks.',
      features: [
        'Step-by-step guidance',
        'Progress tracking',
        'Resource recommendations',
        'Certification milestones',
      ],
    },
    codereview: {
      title: 'Peer Code Review',
      description: 'Get your code reviewed by experienced developers.',
      features: [
        'Detailed feedback',
        'Rating system',
        'Best practices suggestions',
        'Follow-up discussions',
      ],
    },
  };

  const info = content[feature as keyof typeof content];

  return (
    <div>
      <h2 className="text-2xl font-bold mb-2">{info.title}</h2>
      <p className="text-gray-600 mb-4">{info.description}</p>
      <h3 className="font-semibold mb-2">Key Features:</h3>
      <ul className="space-y-2">
        {info.features.map((f, idx) => (
          <li key={idx} className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <span>{f}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}