import React, { useState, useEffect } from 'react';
import { motion, useMotionValue, useTransform, PanInfo } from 'motion/react';
import { 
  Heart, 
  X, 
  MapPin, 
  Clock, 
  Briefcase, 
  Star, 
  RotateCcw, 
  Filter, 
  Users, 
  MessageCircle, 
  Code2,
  Target,
  TrendingUp,
  CheckCircle2,
  Send,
  Sparkles,
  Award,
  Zap,
  ArrowLeft,
  ArrowRight,
  Info,
  ThumbsUp
} from 'lucide-react';
import { Card, CardContent } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { DashboardLayout } from '../components/DashboardLayout';
import { useAuth } from '../contexts/AuthContext';
import { mockUsers, mockCurrentUser } from '../lib/mockData';
import { generateMatches } from '../lib/matchingAlgorithm';
import { Match as MatchType } from '../lib/types';
import { addActivity } from '../lib/userStats';

export function Match() {
  const { user } = useAuth();
  const currentUser = user || mockCurrentUser; // Fallback to mock user for demo
  
  const [matches, setMatches] = useState<MatchType[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [savedMatches, setSavedMatches] = useState<MatchType[]>([]);
  const [passedMatches, setPassedMatches] = useState<string[]>([]);
  const [superLikes, setSuperLikes] = useState(3);
  const [history, setHistory] = useState<{ match: MatchType; action: 'like' | 'pass'; index: number }[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [showTeamBuilder, setShowTeamBuilder] = useState(false);
  const [selectedTeamMembers, setSelectedTeamMembers] = useState<MatchType[]>([]);
  const [teamName, setTeamName] = useState('');
  
  // Filter states
  const [filters, setFilters] = useState({
    experience: 'All',
    availability: 'All',
    minCompatibility: 0
  });

  // Generate matches on mount or when filters change
  useEffect(() => {
    const allMatches = generateMatches(currentUser, mockUsers);
    
    // Apply filters
    const filtered = allMatches.filter(match => {
      const experienceMatch = filters.experience === 'All' || match.user.experience === filters.experience;
      const availabilityMatch = filters.availability === 'All' || match.user.availability === filters.availability;
      const compatibilityMatch = match.compatibilityScore >= filters.minCompatibility;
      
      return experienceMatch && availabilityMatch && compatibilityMatch;
    });
    
    setMatches(filtered);
    setCurrentIndex(0);
  }, [filters]);

  const currentMatch = matches[currentIndex];
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 200], [-25, 25]);
  const opacity = useTransform(x, [-200, -100, 0, 100, 200], [0, 1, 1, 1, 0]);

  const handleDragEnd = (_: any, info: PanInfo) => {
    if (Math.abs(info.offset.x) > 100) {
      if (info.offset.x > 0) {
        handleLike();
      } else {
        handlePass();
      }
    }
  };

  const handleLike = () => {
    if (currentMatch) {
      setSavedMatches([...savedMatches, currentMatch]);
      setHistory([...history, { match: currentMatch, action: 'like', index: currentIndex }]);
      setCurrentIndex(prev => prev + 1);
      
      // Add activity to user stats with proper parameters
      addActivity(
        user?.email || 'default',
        'match',
        `Matched with ${currentMatch.user.name}`,
        10
      );
    }
  };

  const handleSuperLike = () => {
    if (currentMatch && superLikes > 0) {
      const superLikedMatch = { ...currentMatch, isSuperLike: true };
      setSavedMatches([...savedMatches, superLikedMatch]);
      setHistory([...history, { match: currentMatch, action: 'like', index: currentIndex }]);
      setSuperLikes(prev => prev - 1);
      setCurrentIndex(prev => prev + 1);
      
      // Add activity to user stats
      addActivity(
        user?.email || 'default',
        'match',
        `Super liked ${currentMatch.user.name}`,
        25
      );
    }
  };

  const handlePass = () => {
    if (currentMatch) {
      setPassedMatches([...passedMatches, currentMatch.id]);
      setHistory([...history, { match: currentMatch, action: 'pass', index: currentIndex }]);
      setCurrentIndex(prev => prev + 1);
    }
  };

  const handleUndo = () => {
    if (history.length > 0) {
      const lastAction = history[history.length - 1];
      setHistory(history.slice(0, -1));
      setCurrentIndex(lastAction.index);
      
      if (lastAction.action === 'like') {
        setSavedMatches(savedMatches.filter(m => m.id !== lastAction.match.id));
        if (lastAction.match.isSuperLike) {
          setSuperLikes(prev => prev + 1);
        }
      } else {
        setPassedMatches(passedMatches.filter(id => id !== lastAction.match.id));
      }
    }
  };

  const toggleTeamMember = (match: MatchType) => {
    if (selectedTeamMembers.find(m => m.id === match.id)) {
      setSelectedTeamMembers(selectedTeamMembers.filter(m => m.id !== match.id));
    } else if (selectedTeamMembers.length < 4) {
      setSelectedTeamMembers([...selectedTeamMembers, match]);
    }
  };

  const handleCreateTeam = () => {
    if (selectedTeamMembers.length > 0) {
      alert(`Team "${teamName || 'My Team'}" created with ${selectedTeamMembers.length + 1} members!`);
      setSelectedTeamMembers([]);
      setTeamName('');
      setShowTeamBuilder(false);
    }
  };

  const resetFilters = () => {
    setFilters({
      experience: 'All',
      availability: 'All',
      minCompatibility: 0
    });
  };

  // Loading or no matches state
  if (matches.length === 0) {
    return (
      <DashboardLayout>
        <div className="flex min-h-[600px] items-center justify-center">
          <Card className="max-w-md p-8 text-center">
            <div className="mb-4 text-6xl">🔍</div>
            <h2 className="mb-2 text-2xl font-bold text-gray-900">No Matches Found</h2>
            <p className="text-gray-600 mb-4">
              Try adjusting your filters to see more potential teammates.
            </p>
            <Button onClick={resetFilters}>Reset Filters</Button>
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  // All caught up state
  if (!currentMatch) {
    return (
      <DashboardLayout>
        <div className="flex min-h-[600px] items-center justify-center">
          <Card className="max-w-md p-8 text-center">
            <div className="mb-4 text-6xl">🎉</div>
            <h2 className="mb-2 text-2xl font-bold text-gray-900">All Caught Up!</h2>
            <p className="text-gray-600 mb-6">
              You've reviewed all available matches. Great job!
            </p>
            <div className="space-y-3">
              <div className="bg-blue-50 rounded-lg p-4 text-left">
                <div className="font-semibold text-gray-900 mb-2">Your Results:</div>
                <div className="space-y-1 text-sm text-gray-600">
                  <div className="flex justify-between">
                    <span>Total reviewed:</span>
                    <span className="font-medium text-gray-900">{history.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Matches saved:</span>
                    <span className="font-medium text-green-600">{savedMatches.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Success rate:</span>
                    <span className="font-medium text-blue-600">
                      {history.length > 0 ? Math.round((savedMatches.length / history.length) * 100) : 0}%
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="flex gap-3 justify-center">
                <Button onClick={() => setCurrentIndex(0)} className="flex-1">
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Review Again
                </Button>
                {savedMatches.length > 0 && (
                  <Button variant="outline" onClick={() => setShowTeamBuilder(true)} className="flex-1">
                    <Users className="h-4 w-4 mr-2" />
                    Build Team
                  </Button>
                )}
              </div>
            </div>
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      {/* Header with Actions */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Find Teammates</h1>
          <p className="mt-2 text-gray-600">
            <span className="font-medium text-green-600">{savedMatches.length}</span> saved • 
            <span className="font-medium text-yellow-600 ml-2">{superLikes}</span> super likes left •
            <span className="ml-2">{matches.length - currentIndex} remaining</span>
          </p>
        </div>
        
        <div className="flex gap-2 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
            className={showFilters ? 'bg-blue-50 border-blue-300' : ''}
          >
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowTeamBuilder(!showTeamBuilder)}
            className={showTeamBuilder ? 'bg-purple-50 border-purple-300' : ''}
          >
            <Users className="h-4 w-4 mr-2" />
            Team Builder {selectedTeamMembers.length > 0 && `(${selectedTeamMembers.length})`}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleUndo}
            disabled={history.length === 0}
          >
            <RotateCcw className="h-4 w-4 mr-2" />
            Undo
          </Button>
        </div>
      </div>

      {/* Filters Panel */}
      {showFilters && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="mb-6"
        >
          <Card className="border-2 border-blue-200 bg-blue-50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                  <Filter className="h-5 w-5 text-blue-600" />
                  Filter Matches
                </h3>
                <Button variant="ghost" size="sm" onClick={resetFilters}>
                  Reset All
                </Button>
              </div>
              
              <div className="grid gap-4 md:grid-cols-3">
                <div className="bg-white rounded-lg p-3">
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Experience Level
                  </label>
                  <select
                    value={filters.experience}
                    onChange={(e) => setFilters({ ...filters, experience: e.target.value })}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option>All</option>
                    <option>Beginner</option>
                    <option>Intermediate</option>
                    <option>Advanced</option>
                  </select>
                </div>
                
                <div className="bg-white rounded-lg p-3">
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Availability
                  </label>
                  <select
                    value={filters.availability}
                    onChange={(e) => setFilters({ ...filters, availability: e.target.value })}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option>All</option>
                    <option>Full-time</option>
                    <option>Part-time</option>
                    <option>Weekends</option>
                  </select>
                </div>
                
                <div className="bg-white rounded-lg p-3">
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Min Compatibility: {filters.minCompatibility}%
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="10"
                    value={filters.minCompatibility}
                    onChange={(e) => setFilters({ ...filters, minCompatibility: parseInt(e.target.value) })}
                    className="w-full accent-blue-600"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>0%</span>
                    <span>100%</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Team Builder Panel */}
      {showTeamBuilder && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="mb-6"
        >
          <Card className="border-2 border-purple-200 bg-purple-50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                    <Users className="h-5 w-5 text-purple-600" />
                    Build Your Dream Team
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Select up to 4 teammates ({selectedTeamMembers.length}/4 selected)
                  </p>
                </div>
              </div>
              
              <div className="mb-4">
                <input
                  type="text"
                  placeholder="Enter team name (optional)"
                  value={teamName}
                  onChange={(e) => setTeamName(e.target.value)}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              
              {selectedTeamMembers.length > 0 ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {/* You (Team Leader) */}
                    <div className="bg-white rounded-lg p-3 border-2 border-purple-300">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="h-10 w-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center text-white font-bold flex-shrink-0">
                          {currentUser.name.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-sm truncate">{currentUser.name}</div>
                          <div className="text-xs text-purple-600 flex items-center gap-1">
                            <Award className="h-3 w-3" />
                            Team Leader
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    {selectedTeamMembers.map((member) => (
                      <div key={member.id} className="bg-white rounded-lg p-3 border border-gray-200">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold flex-shrink-0">
                            {member.user.name.charAt(0)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="font-medium text-sm truncate">{member.user.name}</div>
                            <div className="text-xs text-green-600">{member.compatibilityScore}% match</div>
                          </div>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          className="w-full text-xs"
                          onClick={() => toggleTeamMember(member)}
                        >
                          <X className="h-3 w-3 mr-1" />
                          Remove
                        </Button>
                      </div>
                    ))}
                  </div>
                  
                  <Button 
                    onClick={handleCreateTeam} 
                    className="w-full bg-purple-600 hover:bg-purple-700"
                  >
                    <Send className="h-4 w-4 mr-2" />
                    Create Team ({selectedTeamMembers.length + 1} members)
                  </Button>
                </div>
              ) : (
                <div className="text-center py-6 bg-white rounded-lg border border-dashed border-gray-300">
                  <Users className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-500 text-sm">
                    Add teammates from your saved matches below
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      )}

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Main Card Stack */}
        <div className="lg:col-span-2">
          <div className="relative h-[650px]">
            {/* Progress Indicator */}
            <div className="mb-3 flex items-center gap-2">
              <div className="flex-1 bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${((currentIndex + 1) / matches.length) * 100}%` }}
                />
              </div>
              <span className="text-sm font-medium text-gray-600">
                {currentIndex + 1} / {matches.length}
              </span>
            </div>

            <motion.div
              key={currentMatch.id}
              style={{ x, rotate, opacity }}
              drag="x"
              dragConstraints={{ left: 0, right: 0 }}
              onDragEnd={handleDragEnd}
              className="absolute inset-0 cursor-grab active:cursor-grabbing"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="h-full overflow-hidden shadow-xl border-2 border-gray-200 hover:shadow-2xl transition-shadow">
                {/* Profile Header with Large Avatar */}
                <div className="relative h-72 bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 overflow-hidden">
                  {/* Decorative Pattern */}
                  <div className="absolute inset-0 opacity-10">
                    <div className="absolute top-0 left-0 w-64 h-64 bg-white rounded-full -translate-x-32 -translate-y-32" />
                    <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full translate-x-32 translate-y-32" />
                  </div>
                  
                  {/* Large Avatar Circle */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <div className="relative">
                      <div className="h-32 w-32 rounded-full bg-white/20 backdrop-blur-sm border-4 border-white shadow-2xl flex items-center justify-center">
                        <span className="text-6xl font-bold text-white">
                          {currentMatch.user.name.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      {/* Online Status Indicator */}
                      <div className="absolute bottom-2 right-2 h-6 w-6 rounded-full bg-green-500 border-4 border-white shadow-lg" />
                    </div>
                    
                    {/* Name and College */}
                    <div className="mt-4 text-center">
                      <h2 className="text-3xl font-bold text-white drop-shadow-lg">
                        {currentMatch.user.name}
                      </h2>
                      <p className="text-white/90 text-lg mt-1 drop-shadow">
                        {currentMatch.user.college}
                      </p>
                    </div>
                  </div>
                  
                  {/* Compatibility Badge */}
                  <div className="absolute top-4 right-4">
                    <div className={`rounded-full px-4 py-2 font-bold shadow-lg ${
                      currentMatch.compatibilityScore >= 80 ? 'bg-green-500 text-white' :
                      currentMatch.compatibilityScore >= 60 ? 'bg-blue-500 text-white' :
                      'bg-white text-blue-600'
                    }`}>
                      {currentMatch.compatibilityScore}% Match
                    </div>
                  </div>
                  
                  {/* Top Prospect Badge */}
                  {currentMatch.compatibilityScore >= 75 && (
                    <div className="absolute top-4 left-4">
                      <Badge className="bg-yellow-400 text-yellow-900 border-yellow-500">
                        <TrendingUp className="h-3 w-3 mr-1" />
                        Top Match
                      </Badge>
                    </div>
                  )}
                </div>

                <CardContent className="p-6 overflow-y-auto max-h-[calc(100%-18rem)]">
                  {/* Quick Stats Bar */}
                  <div className="mb-6 grid grid-cols-3 gap-3">
                    <div className="bg-blue-50 rounded-lg p-3 text-center border border-blue-200">
                      <div className="flex items-center justify-center gap-1 mb-1">
                        <Briefcase className="h-4 w-4 text-blue-600" />
                      </div>
                      <div className="text-xs font-medium text-gray-600">Experience</div>
                      <div className="text-sm font-bold text-blue-600">{currentMatch.user.experience}</div>
                    </div>
                    <div className="bg-green-50 rounded-lg p-3 text-center border border-green-200">
                      <div className="flex items-center justify-center gap-1 mb-1">
                        <Clock className="h-4 w-4 text-green-600" />
                      </div>
                      <div className="text-xs font-medium text-gray-600">Availability</div>
                      <div className="text-sm font-bold text-green-600">{currentMatch.user.availability}</div>
                    </div>
                    <div className="bg-purple-50 rounded-lg p-3 text-center border border-purple-200">
                      <div className="flex items-center justify-center gap-1 mb-1">
                        <Code2 className="h-4 w-4 text-purple-600" />
                      </div>
                      <div className="text-xs font-medium text-gray-600">Skills</div>
                      <div className="text-sm font-bold text-purple-600">{currentMatch.user.skills.length}</div>
                    </div>
                  </div>

                  {/* Bio Section */}
                  <div className="mb-6">
                    <h3 className="mb-2 font-semibold text-gray-900 flex items-center gap-2">
                      <Info className="h-4 w-4 text-gray-600" />
                      About
                    </h3>
                    <p className="text-gray-700 leading-relaxed text-sm bg-gray-50 rounded-lg p-3 border border-gray-200">
                      {currentMatch.user.bio}
                    </p>
                  </div>

                  {/* Skill Compatibility Breakdown */}
                  {currentMatch.skillOverlap.length > 0 && (
                    <div className="mb-4 rounded-lg bg-gradient-to-r from-green-50 to-emerald-50 p-4 border-2 border-green-300 shadow-sm">
                      <h3 className="mb-3 font-semibold text-green-900 flex items-center gap-2">
                        <CheckCircle2 className="h-5 w-5" />
                        Shared Skills ({currentMatch.skillOverlap.length})
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {currentMatch.skillOverlap.map(skill => (
                          <Badge key={skill} className="bg-green-600 text-white border-green-700 shadow-sm">
                            <Code2 className="h-3 w-3 mr-1" />
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="mb-4">
                    <h3 className="mb-3 font-semibold text-gray-900 flex items-center gap-2">
                      <Zap className="h-4 w-4 text-yellow-600" />
                      All Skills
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {currentMatch.user.skills.map(skill => {
                        const isOverlap = currentMatch.skillOverlap.includes(skill);
                        return (
                          <Badge
                            key={skill}
                            variant={isOverlap ? 'default' : 'secondary'}
                            className={isOverlap ? 'bg-green-600 border-green-700 shadow-sm' : 'bg-gray-100 text-gray-700 border-gray-300'}
                          >
                            {skill}
                          </Badge>
                        );
                      })}
                    </div>
                  </div>

                  <div className="mb-4">
                    <h3 className="mb-3 font-semibold text-gray-900 flex items-center gap-2">
                      <Target className="h-4 w-4 text-purple-600" />
                      Interests
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {currentMatch.user.interests.map(interest => (
                        <Badge key={interest} variant="secondary" className="bg-purple-100 text-purple-700 border-purple-300">
                          {interest}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* AI Matching Explanation */}
                  <div className="rounded-lg bg-gradient-to-r from-blue-50 to-indigo-50 p-4 border-2 border-blue-300 shadow-sm">
                    <h3 className="mb-2 font-semibold text-blue-900 flex items-center gap-2">
                      <Sparkles className="h-4 w-4" />
                      AI Match Analysis
                    </h3>
                    <p className="text-sm text-blue-700 leading-relaxed">{currentMatch.explanation}</p>
                  </div>

                  {/* Contact Preview Section */}
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <div className="grid grid-cols-2 gap-3">
                      <Button variant="outline" size="sm" className="w-full">
                        <MessageCircle className="h-4 w-4 mr-2" />
                        Message
                      </Button>
                      <Button variant="outline" size="sm" className="w-full">
                        <Users className="h-4 w-4 mr-2" />
                        View Profile
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Action Buttons */}
            <div className="absolute -bottom-20 left-1/2 flex -translate-x-1/2 gap-4">
              <Button
                onClick={handlePass}
                size="lg"
                variant="outline"
                className="h-16 w-16 rounded-full border-2 border-red-300 bg-white hover:bg-red-50 hover:border-red-400 transition-all"
                title="Pass"
              >
                <X className="h-8 w-8 text-red-600" />
              </Button>
              
              <Button
                onClick={handleSuperLike}
                size="lg"
                variant="outline"
                disabled={superLikes === 0}
                className="h-16 w-16 rounded-full border-2 border-yellow-300 bg-white hover:bg-yellow-50 hover:border-yellow-400 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                title={`Super Like (${superLikes} left)`}
              >
                <Star className={`h-8 w-8 ${superLikes > 0 ? 'text-yellow-600' : 'text-gray-400'}`} />
              </Button>

              <Button
                onClick={handleLike}
                size="lg"
                className="h-16 w-16 rounded-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 shadow-lg hover:shadow-xl transition-all"
                title="Like"
              >
                <Heart className="h-8 w-8" />
              </Button>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="lg:col-span-1 space-y-4">
          {/* Saved Matches */}
          <Card>
            <CardContent className="p-6">
              <h3 className="mb-4 font-semibold text-gray-900 flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-green-600" />
                  Saved Matches
                </span>
                <span className="text-sm font-normal text-gray-500">
                  {savedMatches.length}
                </span>
              </h3>
              
              <div className="space-y-3 max-h-[400px] overflow-y-auto">
                {savedMatches.length === 0 ? (
                  <div className="text-center py-8 bg-gray-50 rounded-lg border border-dashed border-gray-300">
                    <Heart className="h-10 w-10 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-500">
                      No saved matches yet
                    </p>
                    <p className="text-xs text-gray-400 mt-1">
                      Start swiping right!
                    </p>
                  </div>
                ) : (
                  savedMatches.slice().reverse().map((match) => (
                    <motion.div
                      key={match.id}
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="rounded-lg border border-gray-200 p-3 hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex items-start gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-purple-600 text-sm font-bold text-white flex-shrink-0 relative">
                          {match.user.name.charAt(0)}
                          {match.isSuperLike && (
                            <div className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-yellow-400 flex items-center justify-center">
                              <Star className="h-3 w-3 fill-yellow-600 text-yellow-600" />
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-gray-900 truncate">
                            {match.user.name}
                          </div>
                          <div className="text-xs text-gray-600 truncate">
                            {match.user.college}
                          </div>
                          <div className="mt-1 flex items-center gap-2">
                            <span className="text-xs font-medium text-green-600">
                              {match.compatibilityScore}% match
                            </span>
                            <button
                              onClick={() => toggleTeamMember(match)}
                              className={`text-xs ${
                                selectedTeamMembers.find(m => m.id === match.id)
                                  ? 'text-purple-600 font-medium'
                                  : 'text-blue-600 hover:text-blue-700'
                              }`}
                            >
                              {selectedTeamMembers.find(m => m.id === match.id) 
                                ? '✓ In Team' 
                                : '+ Add to team'}
                            </button>
                          </div>
                        </div>
                      </div>
                      <div className="mt-2 flex gap-2">
                        <Button size="sm" variant="outline" className="flex-1 text-xs">
                          <MessageCircle className="h-3 w-3 mr-1" />
                          Message
                        </Button>
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Match Statistics */}
          <Card className="bg-gradient-to-br from-blue-50 to-purple-50">
            <CardContent className="p-6">
              <h3 className="mb-4 font-semibold text-gray-900 flex items-center gap-2">
                <Award className="h-5 w-5 text-purple-600" />
                Your Stats
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center bg-white rounded-lg p-3">
                  <span className="text-sm text-gray-600">Profiles viewed</span>
                  <span className="font-bold text-lg text-gray-900">{history.length}</span>
                </div>
                <div className="flex justify-between items-center bg-white rounded-lg p-3">
                  <span className="text-sm text-gray-600">Matches saved</span>
                  <span className="font-bold text-lg text-green-600">{savedMatches.length}</span>
                </div>
                <div className="flex justify-between items-center bg-white rounded-lg p-3">
                  <span className="text-sm text-gray-600">Success rate</span>
                  <span className="font-bold text-lg text-blue-600">
                    {history.length > 0 ? Math.round((savedMatches.length / history.length) * 100) : 0}%
                  </span>
                </div>
                <div className="flex justify-between items-center bg-white rounded-lg p-3">
                  <span className="text-sm text-gray-600">Super Likes</span>
                  <div className="flex gap-1">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${i < superLikes ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Tips */}
          <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
            <CardContent className="p-6">
              <h3 className="mb-3 font-semibold text-gray-900 flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-purple-600" />
                Pro Tips
              </h3>
              <ul className="space-y-2 text-sm text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-green-600">❤️</span>
                  <span>Swipe right or click to save matches</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-yellow-600">⭐</span>
                  <span>Use super likes for top prospects</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600">🔍</span>
                  <span>Apply filters to refine matches</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-600">👥</span>
                  <span>Build teams from saved matches</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}